Add to project codemirror.net for 1C languge.
Дополнения для проекта codemirror.net для языка 1С.
MIT licence as parent - http://codemirror.net/LICENSE

Work file
рабочие файлы:
- mode/1c/1c.js
- theme/1c.scc
- index.html - test 

Тема сделана по цветовому оформлению в 1С по умолчанию и полностью соответствует работе внутри самой систеиы 1С. 
Цветовое оформление не самое приятное на вид, но узнаваемое при любом кусочке кода. Будем его придерживаться.
